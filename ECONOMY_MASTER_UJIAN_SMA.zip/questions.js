// ================================================================
// BANK SOAL EKONOMI SMA
// Kamu cukup mengedit file ini untuk mengganti / menambah soal.
// correct = indeks jawaban benar, dimulai dari 0.
// difficulty: MUDAH / SEDANG / SULIT / HOTS
// ================================================================

const QUIZ_CONFIG = {
  defaultMinutes: 30,
  classes: [
    { id:"x", label:"Kelas X", subtitle:"Dasar-Dasar Ekonomi", color:"green" },
    { id:"xi", label:"Kelas XI", subtitle:"Ekonomi Makro & Kebijakan", color:"blue" },
    { id:"xii", label:"Kelas XII", subtitle:"Akuntansi & Ekonomi Internasional", color:"gold" }
  ]
};

const QUESTIONS = [
  // ======================= KELAS X =======================
  {id:"x1",class:"x",topic:"Konsep Dasar Ekonomi",difficulty:"MUDAH",
   question:"Masalah ekonomi muncul terutama karena...",
   options:["kebutuhan manusia terbatas","alat pemuas kebutuhan terbatas sementara kebutuhan relatif tidak terbatas","semua barang memiliki harga tinggi","distribusi selalu tidak merata"],
   correct:1,explanation:"Kelangkaan terjadi karena alat pemuas kebutuhan terbatas sedangkan kebutuhan manusia relatif tidak terbatas."},

  {id:"x2",class:"x",topic:"Biaya Peluang",difficulty:"SEDANG",
   question:"Seorang siswa memilih bekerja paruh waktu daripada mengikuti kursus. Biaya peluang dari keputusan tersebut adalah...",
   options:["uang yang diterima dari pekerjaan","waktu perjalanan ke tempat kerja","kesempatan mengikuti kursus yang dikorbankan","biaya makan selama bekerja"],
   correct:2,explanation:"Biaya peluang adalah alternatif terbaik yang dikorbankan ketika memilih suatu pilihan."},

  {id:"x3",class:"x",topic:"Kegiatan Ekonomi",difficulty:"MUDAH",
   question:"Kegiatan mengubah bahan baku menjadi barang yang memiliki nilai guna lebih tinggi disebut...",
   options:["konsumsi","distribusi","produksi","investasi"],
   correct:2,explanation:"Produksi adalah kegiatan menghasilkan atau menambah nilai guna barang dan jasa."},

  {id:"x4",class:"x",topic:"Permintaan",difficulty:"SEDANG",
   question:"Jika harga suatu barang naik dan faktor lain tetap, menurut hukum permintaan jumlah yang diminta cenderung...",
   options:["naik","turun","tetap","menjadi nol"],
   correct:1,explanation:"Hukum permintaan menyatakan hubungan berlawanan arah antara harga dan jumlah yang diminta, ceteris paribus."},

  {id:"x5",class:"x",topic:"Keseimbangan Pasar",difficulty:"HOTS",
   question:"Jika jumlah yang ditawarkan lebih besar daripada jumlah yang diminta pada suatu harga, kondisi pasar disebut...",
   options:["shortage","equilibrium","surplus","inflasi"],
   correct:2,explanation:"Surplus terjadi ketika jumlah penawaran melebihi jumlah permintaan."},

  {id:"x6",class:"x",topic:"Uang",difficulty:"MUDAH",
   question:"Fungsi uang sebagai alat untuk mengukur nilai barang disebut...",
   options:["alat tukar","satuan hitung","alat pembayaran utang","penimbun kekayaan"],
   correct:1,explanation:"Uang sebagai satuan hitung digunakan untuk menyatakan nilai atau harga barang dan jasa."},

  {id:"x7",class:"x",topic:"Perbankan",difficulty:"SEDANG",
   question:"Lembaga yang memiliki kewenangan utama dalam menjaga kestabilan nilai rupiah adalah...",
   options:["Bank Indonesia","BPR","koperasi","pegadaian"],
   correct:0,explanation:"Bank Indonesia merupakan bank sentral Indonesia dengan tugas menjaga kestabilan nilai rupiah."},

  {id:"x8",class:"x",topic:"Badan Usaha",difficulty:"MUDAH",
   question:"Badan usaha yang modalnya sebagian besar atau seluruhnya dimiliki negara disebut...",
   options:["BUMN","BUMS","koperasi","firma"],
   correct:0,explanation:"BUMN adalah badan usaha yang modalnya dimiliki negara, baik seluruh maupun sebagian besar sesuai bentuknya."},

  // ======================= KELAS XI =======================
  {id:"xi1",class:"xi",topic:"Pendapatan Nasional",difficulty:"SEDANG",
   question:"Pendekatan pengeluaran dalam menghitung pendapatan nasional dirumuskan sebagai...",
   options:["Y = C + I + G + (X − M)","Y = W + R + I + P","Y = produksi − konsumsi","Y = C − I + G"],
   correct:0,explanation:"Rumus pendekatan pengeluaran adalah Y = C + I + G + (X − M)."},

  {id:"xi2",class:"xi",topic:"Pertumbuhan Ekonomi",difficulty:"MUDAH",
   question:"Pertumbuhan ekonomi secara umum menunjukkan...",
   options:["penurunan produksi nasional","kenaikan kapasitas produksi atau output riil dari waktu ke waktu","kenaikan harga semata","bertambahnya jumlah uang tanpa perubahan output"],
   correct:1,explanation:"Pertumbuhan ekonomi berkaitan dengan peningkatan output atau kapasitas produksi riil dalam periode tertentu."},

  {id:"xi3",class:"xi",topic:"Ketenagakerjaan",difficulty:"SEDANG",
   question:"Pengangguran yang terjadi karena perubahan struktur ekonomi sehingga keterampilan pekerja tidak lagi sesuai disebut...",
   options:["friksional","struktural","musiman","sukarela"],
   correct:1,explanation:"Pengangguran struktural terjadi karena perubahan struktur ekonomi atau teknologi yang membuat keterampilan tertentu tidak lagi sesuai."},

  {id:"xi4",class:"xi",topic:"Inflasi",difficulty:"MUDAH",
   question:"Inflasi adalah kondisi ketika...",
   options:["harga satu barang turun","tingkat harga umum naik secara terus-menerus","pendapatan selalu naik","produksi selalu turun"],
   correct:1,explanation:"Inflasi adalah kenaikan tingkat harga umum secara terus-menerus dalam perekonomian."},

  {id:"xi5",class:"xi",topic:"Kebijakan Moneter",difficulty:"SEDANG",
   question:"Kebijakan moneter kontraktif bertujuan utama untuk...",
   options:["mendorong permintaan agregat tanpa batas","mengurangi tekanan inflasi dengan mengetatkan kondisi moneter","menghapus pajak","meningkatkan impor"],
   correct:1,explanation:"Kebijakan moneter kontraktif digunakan untuk mengurangi tekanan inflasi, antara lain dengan mengurangi pertumbuhan uang/kredit."},

  {id:"xi6",class:"xi",topic:"APBN",difficulty:"MUDAH",
   question:"APBN adalah...",
   options:["rencana keuangan tahunan pemerintah pusat","laporan keuangan perusahaan","anggaran setiap rumah tangga","rencana keuangan bank umum"],
   correct:0,explanation:"APBN merupakan rencana keuangan tahunan pemerintahan negara yang disetujui oleh DPR."},

  {id:"xi7",class:"xi",topic:"Pajak",difficulty:"SEDANG",
   question:"Salah satu fungsi pajak sebagai sumber penerimaan negara disebut fungsi...",
   options:["distribusi","budgeter","regulasi","stabilisasi"],
   correct:1,explanation:"Fungsi budgeter berarti pajak menjadi sumber penerimaan untuk membiayai pengeluaran negara."},

  {id:"xi8",class:"xi",topic:"Perdagangan Internasional",difficulty:"HOTS",
   question:"Keunggulan komparatif menjelaskan bahwa suatu negara sebaiknya...",
   options:["memproduksi semua barang sendiri","berspesialisasi pada barang yang memiliki biaya peluang relatif lebih rendah","menghindari perdagangan","hanya mengimpor barang mahal"],
   correct:1,explanation:"Teori keunggulan komparatif mendorong spesialisasi berdasarkan biaya peluang relatif yang lebih rendah."},

  // ======================= KELAS XII =======================
  {id:"xii1",class:"xii",topic:"Persamaan Dasar Akuntansi",difficulty:"MUDAH",
   question:"Persamaan dasar akuntansi yang benar adalah...",
   options:["Aset = Liabilitas + Ekuitas","Aset = Pendapatan − Beban","Ekuitas = Aset + Liabilitas","Liabilitas = Aset + Ekuitas"],
   correct:0,explanation:"Persamaan dasar akuntansi adalah Aset = Liabilitas + Ekuitas."},

  {id:"xii2",class:"xii",topic:"Debit & Kredit",difficulty:"SEDANG",
   question:"Secara umum, penambahan aset dicatat pada sisi...",
   options:["kredit","debit","saldo","modal"],
   correct:1,explanation:"Akun aset bertambah di sisi debit dan berkurang di sisi kredit."},

  {id:"xii3",class:"xii",topic:"Jurnal Umum",difficulty:"MUDAH",
   question:"Fungsi utama jurnal umum adalah...",
   options:["mencatat transaksi secara kronologis sebelum diposting ke buku besar","menghitung pajak negara","menentukan harga pasar","mencatat hanya transaksi tunai"],
   correct:0,explanation:"Jurnal umum merupakan pencatatan awal transaksi secara kronologis berdasarkan bukti transaksi."},

  {id:"xii4",class:"xii",topic:"Laporan Keuangan",difficulty:"SEDANG",
   question:"Laporan yang menunjukkan pendapatan dan beban untuk menentukan laba atau rugi adalah...",
   options:["neraca","laporan laba rugi","laporan arus kas","jurnal umum"],
   correct:1,explanation:"Laporan laba rugi menyajikan pendapatan dan beban selama periode tertentu untuk memperoleh laba/rugi."},

  {id:"xii5",class:"xii",topic:"Perusahaan Dagang",difficulty:"HOTS",
   question:"Dalam perusahaan dagang, harga pokok penjualan berkaitan langsung dengan...",
   options:["persediaan barang dagang yang dijual","jumlah modal pemilik saja","beban listrik saja","utang bank saja"],
   correct:0,explanation:"HPP menggambarkan biaya perolehan barang dagang yang telah terjual dalam suatu periode."},

  {id:"xii6",class:"xii",topic:"Kurs Valuta Asing",difficulty:"SEDANG",
   question:"Jika nilai rupiah melemah terhadap dolar AS, barang impor dari AS bagi pembeli Indonesia cenderung menjadi...",
   options:["lebih murah","lebih mahal","gratis","tidak berubah dalam semua kondisi"],
   correct:1,explanation:"Depresiasi rupiah membuat kebutuhan rupiah untuk memperoleh satu dolar menjadi lebih besar, sehingga impor dari AS cenderung lebih mahal."},

  {id:"xii7",class:"xii",topic:"Neraca Pembayaran",difficulty:"SULIT",
   question:"Neraca pembayaran secara umum mencatat...",
   options:["seluruh transaksi ekonomi antara penduduk suatu negara dan luar negeri dalam periode tertentu","hanya transaksi ekspor barang","hanya transaksi pemerintah","hanya penerimaan pajak"],
   correct:0,explanation:"Neraca pembayaran mencatat transaksi ekonomi antara penduduk suatu negara dengan penduduk negara lain dalam periode tertentu."},

  {id:"xii8",class:"xii",topic:"Ekonomi Digital",difficulty:"HOTS",
   question:"Salah satu manfaat ekonomi digital bagi pelaku usaha adalah...",
   options:["mempersempit akses pasar","mempermudah transaksi dan memperluas jangkauan pasar","menghilangkan seluruh risiko usaha","menjamin semua usaha pasti untung"],
   correct:1,explanation:"Platform digital dapat memperluas jangkauan pasar dan mempermudah proses transaksi, meskipun risiko usaha tetap ada."}
];