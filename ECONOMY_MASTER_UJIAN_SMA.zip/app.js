let state = { questions:[], index:0, answers:[], endAt:0, timer:null, classId:null };

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function show(id){
  $$(".screen").forEach(x=>x.classList.remove("active"));
  $(id).classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
}

function init(){
  state.questions = QUESTIONS.slice();
  $("#statQuestions").textContent = QUESTIONS.length;
  $("#statMinutes").textContent = QUIZ_CONFIG.defaultMinutes;
  renderClassCards();
  $("#startAllBtn").onclick = () => startQuiz("all");
  $("#howBtn").onclick = () => $("#modal").classList.remove("hidden");
  $("#closeModal").onclick = () => $("#modal").classList.add("hidden");
  $("#themeBtn").onclick = toggleTheme;
  $("#backBtn").onclick = confirmExit;
  $("#finishBtn").onclick = () => finishQuiz(false);
  $("#prevBtn").onclick = () => { if(state.index>0){state.index--;renderQuestion();} };
  $("#nextBtn").onclick = () => { if(state.index<state.questions.length-1){state.index++;renderQuestion();} else finishQuiz(false); };
  $("#retryBtn").onclick = () => startQuiz(state.classId || "all");
  $("#homeBtn").onclick = () => show("#homeScreen");
  $("#reviewBtn").onclick = () => $("#reviewList").scrollIntoView({behavior:"smooth"});
  $("#progressMini").textContent = `0 / ${QUESTIONS.length}`;
}
function renderClassCards(){
  const counts = Object.fromEntries(QUIZ_CONFIG.classes.map(c=>[c.id,QUESTIONS.filter(q=>q.class===c.id).length]));
  $("#classCards").innerHTML = QUIZ_CONFIG.classes.map(c=>`
    <button class="class-card" data-class="${c.id}">
      <div class="num">${c.label.toUpperCase()}</div><h3>${c.subtitle}</h3>
      <p>${counts[c.id]} soal tersedia • Pilihan ganda • Pembahasan</p><span class="arrow">→</span>
    </button>`).join("");
  $$(".class-card").forEach(b=>b.onclick=()=>startQuiz(b.dataset.class));
}
function startQuiz(classId){
  state.classId = classId;
  state.questions = classId==="all" ? QUESTIONS.slice() : QUESTIONS.filter(q=>q.class===classId);
  if(!state.questions.length) return;
  state.index=0; state.answers=Array(state.questions.length).fill(null);
  state.endAt=Date.now()+QUIZ_CONFIG.defaultMinutes*60*1000;
  clearInterval(state.timer); state.timer=setInterval(updateTimer,250);
  const label=classId==="all"?"Kelas X–XII":QUIZ_CONFIG.classes.find(c=>c.id===classId).label;
  $("#quizClass").textContent=label; $("#quizTopic").textContent="Latihan Ekonomi SMA";
  show("#quizScreen"); renderQuestion(); updateTimer();
}
function renderQuestion(){
  const q=state.questions[state.index], total=state.questions.length, selected=state.answers[state.index];
  $("#questionNumber").textContent=`SOAL ${String(state.index+1).padStart(2,"0")}`;
  $("#difficulty").textContent=q.difficulty;
  $("#quizTopic").textContent=q.topic;
  $("#questionText").textContent=q.question;
  $("#options").innerHTML=q.options.map((o,i)=>`
    <button class="option ${selected===i?"selected":""}" data-i="${i}">
      <span class="letter">${String.fromCharCode(65+i)}</span><span>${escapeHtml(o)}</span>
    </button>`).join("");
  $$(".option").forEach(b=>b.onclick=()=>{state.answers[state.index]=Number(b.dataset.i);renderQuestion();});
  $("#prevBtn").disabled=state.index===0;
  $("#nextBtn").textContent=state.index===total-1?"Kumpulkan →":"Berikutnya →";
  $("#progressBar").style.width=`${((state.index+1)/total)*100}%`;
  $("#progressMini").textContent=`${state.index+1} / ${total}`;
  renderNumberGrid();
}
function renderNumberGrid(){
  $("#numberGrid").innerHTML=state.questions.map((q,i)=>`
    <button class="num-btn ${i===state.index?"current":""} ${state.answers[i]!==null?"answered":""}" data-i="${i}">${i+1}</button>`).join("");
  $$("#numberGrid .num-btn").forEach(b=>b.onclick=()=>{state.index=Number(b.dataset.i);renderQuestion();});
  $("#answeredCount").textContent=`${state.answers.filter(x=>x!==null).length} terjawab`;
}
function updateTimer(){
  const left=Math.max(0,state.endAt-Date.now()), sec=Math.ceil(left/1000);
  const m=Math.floor(sec/60), s=sec%60;
  $("#timer").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
  $("#timer").classList.toggle("safe",sec>300);
  if(left<=0){clearInterval(state.timer);finishQuiz(true);}
}
function finishQuiz(auto){
  clearInterval(state.timer);
  const total=state.questions.length, correct=state.questions.reduce((n,q,i)=>n+(state.answers[i]===q.correct?1:0),0);
  const answered=state.answers.filter(x=>x!==null).length, wrong=answered-correct, blank=total-answered, score=Math.round(correct/total*100);
  $("#score").textContent=score; $("#correct").textContent=correct; $("#wrong").textContent=wrong; $("#unanswered").textContent=blank;
  $("#resultTitle").textContent=score>=85?"Luar biasa!":score>=70?"Bagus!":score>=55?"Lumayan, terus latihan!":"Jangan menyerah!";
  $("#resultSummary").textContent=auto?"Waktu habis. Berikut hasil ujianmu.":`Kamu menjawab ${answered} dari ${total} soal.`;
  const deg=Math.round(score*3.6); $(".score-ring").style.background=`conic-gradient(var(--accent) ${deg}deg,#1b314b ${deg}deg)`;
  $("#reviewList").innerHTML=state.questions.map((q,i)=>{
    const ok=state.answers[i]===q.correct;
    const your=state.answers[i]===null?"Tidak dijawab":q.options[state.answers[i]];
    return `<div class="review-item ${ok?"correct":"wrong"}"><div class="review-q">${i+1}. ${escapeHtml(q.question)}</div>
      <div class="review-a">Jawabanmu: <b>${escapeHtml(your)}</b><br>Jawaban benar: <b>${escapeHtml(q.options[q.correct])}</b></div>
      <div class="review-exp">${escapeHtml(q.explanation||"Tidak ada pembahasan.")}</div></div>`;
  }).join("");
  show("#resultScreen");
}
function confirmExit(){
  if(confirm("Keluar dari ujian? Jawaban yang sedang dikerjakan akan hilang.")){clearInterval(state.timer);show("#homeScreen");}
}
function toggleTheme(){
  document.body.classList.toggle("light");
  $("#themeBtn").textContent=document.body.classList.contains("light")?"☀":"☾";
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
document.addEventListener("DOMContentLoaded",init);
