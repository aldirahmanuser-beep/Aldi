ECONOMY MASTER — Ujian Ekonomi SMA X–XII

CARA MENJALANKAN:
1. Buka index.html di browser.
2. Tidak membutuhkan server/backend untuk versi ini.
3. Semua soal ada di questions.js.
4. Edit QUESTIONS untuk menambah/menghapus/mengubah soal.
5. QUIZ_CONFIG.defaultMinutes mengatur timer default.

FORMAT SOAL:
{
  id:"unik",
  class:"x",              // x, xi, xii
  topic:"Nama Materi",
  difficulty:"SEDANG",   // MUDAH/SEDANG/SULIT/HOTS
  question:"Pertanyaan...",
  options:["A","B","C","D"],
  correct:1,              // indeks jawaban benar: 0=A, 1=B, 2=C, 3=D
  explanation:"Pembahasan..."
}

Catatan:
- Timer berlaku untuk satu sesi ujian.
- Skor dihitung otomatis.
- Review menampilkan jawaban benar dan pembahasan.
- Tampilan responsif untuk HP dan desktop.
